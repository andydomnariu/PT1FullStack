import { Controller, Post, Body } from '@nestjs/common';
import { NotificationService } from './notification.service';

@Controller('notifications')
export class NotificationController {
  constructor(private readonly notificationService: NotificationService) {}

  @Post('disconnection-alert')
  async sendDisconnectionAlert(@Body('email') email: string) {
    await this.notificationService.notifyDisconnection(email);
  }
}
