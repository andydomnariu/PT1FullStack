import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { NotificationService } from './notification.service';
import { NotificationController } from './notification.controller';
import { MailerService } from '../mailer/mailer.service';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'mail-queue',
    }),
  ],
  providers: [NotificationService, MailerService],
  controllers: [NotificationController],
  exports: [NotificationService],
})
export class NotificationModule {}
