import { Injectable } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bullmq';
import { Queue } from 'bullmq';
import { MailerService } from '../mailer/mailer.service';

@Injectable()
export class NotificationService {
  constructor(
    @InjectQueue('mail-queue') private readonly mailQueue: Queue,
    private readonly mailerService: MailerService
  ) {}

  async notifyDisconnection(email: string) {
    await this.mailQueue.add('send-email', {
      to: email,
      subject: 'Alarma de Desconexión',
      text: 'Se ha detectado una desconexión en el sistema.',
    });
  }
}
