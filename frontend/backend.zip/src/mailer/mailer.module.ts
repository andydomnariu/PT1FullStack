import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { MailerProcessor } from './mailer.processor';
import { MailerService } from './mailer.service';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'mail-queue',
    }),
  ],
  providers: [MailerProcessor, MailerService],
})
export class MailerModule {}
