import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Job } from 'bullmq';
import * as nodemailer from 'nodemailer';

@Processor('mail-queue')
export class MailerProcessor extends WorkerHost {
  private transporter;

  constructor() {
    super();
    this.transporter = nodemailer.createTransport({
      host: 'smtp.mailtrap.io',
      port: 2525,
      auth: {
        user: 'Andrei Domnariu',
        pass: 'AD12345!!',
      },
    });
  }

  async process(job: Job<any>): Promise<void> {
    const { to, subject, text } = job.data

    await this.transporter.sendMail({
      from: '"No Reply" <noreply@example.com>',
      to,
      subject,
      text,
    });

    console.log(`Mail sent to ${to}`);
  }
}
