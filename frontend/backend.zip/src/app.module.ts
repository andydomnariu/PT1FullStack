import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bullmq';
import { UsersModule } from './users/users.module';
import { AppGateway } from './app.gateway';
import { WeatherService } from './weather/weather.service';
import { NotificationModule } from './notification/notification.module';
import { MailerModule } from './mailer/mailer.module';

@Module({
  imports: [
    UsersModule,
    BullModule.forRoot({
      connection: {
        host: 'localhost',
        port: 6379,
      },
    }),
    NotificationModule,
    MailerModule,
  ],
  providers: [AppGateway, WeatherService],
})
export class AppModule { }
