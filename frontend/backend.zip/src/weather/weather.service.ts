import { Injectable, Logger } from '@nestjs/common';
import axios from 'axios';
import { AppGateway } from '../app.gateway';

@Injectable()
export class WeatherService {
  private readonly logger = new Logger(WeatherService.name);
  private apiKey = 'c934e2678c5f830f8af6ec1a479cfe25';
  private location = 'London';

  constructor(private appGateway: AppGateway) {
    this.fetchWeatherData();
    setInterval(() => this.fetchWeatherData(), 5000);
  }

  private async fetchWeatherData() {
    try {
      const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${this.location}&appid=${this.apiKey}`);
      const weatherData = response.data;
      this.appGateway.server.emit('dataUpdate', weatherData);
    } catch (error) {
      this.logger.error('Failed to fetch weather data', error);
    }
  }
}
