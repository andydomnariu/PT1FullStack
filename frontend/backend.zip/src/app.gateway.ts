import {
  WebSocketGateway,
  WebSocketServer,
  OnGatewayConnection,
  OnGatewayDisconnect,
  SubscribeMessage,
} from '@nestjs/websockets';
import { Server } from 'socket.io';
import { UsersService } from './users/users.service';

@WebSocketGateway()
export class AppGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;

  constructor(private usersService: UsersService) { }



  async handleConnection(client: any) {
    console.log('Client connected');
  }

  async handleDisconnect(client: any) {
    console.log('Client disconnected');
  }

  @SubscribeMessage('signUp')
  async handleSignUp(client: any, payload: any): Promise<void> {
    try {
      await this.usersService.create(payload);
      client.emit('signUpSuccess', { success: true });
    } catch (error) {
      client.emit('signUpError', { success: false, error: error.message });
    }
  }

  @SubscribeMessage('login')
  async handleLogin(client: any, { username, password }: { username: string; password: string }): Promise<void> {
    try {
      const user = await this.usersService.findByUsername(username);
      if (user && user.password === password) {
        client.emit('loginSuccess', { success: true });
      } else {
        client.emit('loginError', { success: false });
      }
    } catch (error) {
      client.emit('loginError', { success: false, error: error.message });
    }
  }

  @SubscribeMessage('searchUser')
  async handleSearchUser(client: any, username: string): Promise<void> {
    try {
      const users = await this.usersService.findByUsername(username);
      client.emit('searchUserResults', users);
    } catch (error) {
      client.emit('searchUserError', { success: false, error: error.message });
    }
  }
}