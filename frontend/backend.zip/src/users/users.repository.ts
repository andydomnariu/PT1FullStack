import { Injectable } from '@nestjs/common';
import { promises as fs } from 'fs';
import { join } from 'path';
import { CreateUserDto } from './dtos/create-user.dto';
import { UpdateUserDto } from './dtos/update-user.dto';

const filePath = join(__dirname, 'users.json');

@Injectable()
export class UsersRepository {
    async findAll(): Promise<any[]> {
        return await this.readData();
    }

    async findOne(id: number): Promise<any> {
        const users = await this.readData();
        return users.find(user => user.id === id);
    }

    async findByUsername(username: string): Promise<any[]> {
        const users = await this.readData();
        return users.filter(user => user.username.includes(username));
    }

    async create(createUserDto: CreateUserDto): Promise<any> {
        const users = await this.readData();
        const user = {
            id: users.length ? users[users.length - 1].id + 1 : 1,
            ...createUserDto,
        };
        users.push(user);
        await this.writeData(users);
        return user;
    }

    async update(id: number, updateUserDto: UpdateUserDto): Promise<void> {
        const users = await this.readData();
        const index = users.findIndex(user => user.id === id);
        if (index === -1) return;
        users[index] = { ...users[index], ...updateUserDto };
        await this.writeData(users);
    }

    async remove(id: number): Promise<void> {
        let users = await this.readData();
        users = users.filter(user => user.id !== id);
        await this.writeData(users);
    }

    private async readData() {
        try {
            const data = await fs.readFile(filePath, 'utf-8');
            return JSON.parse(data);
        } catch (error) {
            if (error.code === 'ENOENT') {
                return [];
            }
            throw error;
        }
    }

    private async writeData(data: any) {
        await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
    }
}