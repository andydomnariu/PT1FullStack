import { Injectable } from '@nestjs/common';
import { UsersRepository } from './users.repository';
import { CreateUserDto } from './dtos/create-user.dto';
import { UpdateUserDto } from './dtos/update-user.dto';

@Injectable()
export class UsersService {
  constructor(private readonly usersRepository: UsersRepository) { }

  async findAll(): Promise<any[]> {
    return this.usersRepository.findAll();
  }

  async findOne(id: number): Promise<any> {
    return this.usersRepository.findOne(id);
  }

  async findByUsername(username: string): Promise<any> {
    const users = await this.usersRepository.findAll();
    return users.find(user => user.username === username);
  }

  async create(createUserDto: CreateUserDto): Promise<any> {
    return this.usersRepository.create(createUserDto);
  }

  async update(id: number, updateUserDto: UpdateUserDto): Promise<void> {
    return this.usersRepository.update(id, updateUserDto);
  }

  async remove(id: number): Promise<void> {
    return this.usersRepository.remove(id);
  }
}
